-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Agu 2023 pada 15.23
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `polkam`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `comments`
--

CREATE TABLE `comments` (
  `uuid` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `post_id` varchar(50) NOT NULL,
  `comment` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `comments`
--

INSERT INTO `comments` (`uuid`, `user_id`, `post_id`, `comment`, `picture`, `created`) VALUES
('360a0f32-a1f8-4e23-9984-6072e3b922f9', '', 'a32ea095-37a8-4988-8b2b-2d69345cf7b8', 'Gunungnya indah Bro.', 'uploads/download.png', '2023-08-25 19:45:30'),
('9d3767c4-8fc0-4c8f-8d6d-4d4aad6d6d2f', '', 'ec2498ce-11de-403d-bc16-bd8a64c15339', 'Mantap bosku', 'uploads/dasd 001.jpg', '2023-08-25 20:09:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `comment_tags`
--

CREATE TABLE `comment_tags` (
  `comment_id` varchar(50) NOT NULL,
  `tag_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `comment_tags`
--

INSERT INTO `comment_tags` (`comment_id`, `tag_id`) VALUES
('f86d99e1-0646-406d-8787-346cdf', '7e7faf11-1c6e-4268-92c8-87ccaa'),
('f86d99e1-0646-406d-8787-346cdfffad7d', '7e7faf11-1c6e-4268-92c8-87ccaa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likes`
--

CREATE TABLE `likes` (
  `like_id` int(11) NOT NULL,
  `post_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE `posts` (
  `uuid` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `post` varchar(250) NOT NULL,
  `post_image` varchar(100) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`uuid`, `user_id`, `post`, `post_image`, `created`) VALUES
('0fb86de2-faba-4fa2-a2cf-36618511faa1', 'e31sd143123dsasd', 'Gunung Kerinci merupakan atap dari Sumatera yang mana di atas sana menyediakan pemandangan yang sangat indah untuk dinikmati bersama teman-teman #gunung', 'uploads/download (2).jpg', '2023-08-25 20:20:19'),
('a32ea095-37a8-4988-8b2b-2d69345cf7b8', '', 'Gunung merupakan sebuah tempat yang banyak dicari oleh pemuda-pemudi masa kini untuk menenangkan diri sejenak dalam hiruk dan pikuk nya dunia ini. #Gunung #AnakGunung', 'uploads/download (2).jpg', '2023-08-25 19:42:11'),
('b7186388-7a70-4825-945a-863d8065c110', 'e31sd143123dsasd', 'Sunset merupakan salah satu yang hal yang paling indah selain melihat senyuman dirimu. #kamu #senyum', 'uploads/', '2023-08-25 20:21:26'),
('d382486c-a8ee-414d-8983-44a72b67633f', 'e31sd143123dsasd', 'Politeknik kampar merupakan salah satu peguruan tinggi yang bergerak di bidang sawit satu-satunya yang ada di kampar. #sawit #kampar', 'uploads/DSC07521.JPG', '2023-08-25 20:19:12'),
('ec2498ce-11de-403d-bc16-bd8a64c15339', '', 'Sunset diatas gunung adalah sesuatu hal yang didamba-dambakan oleh semua pendaki, karena ketika kita melihat sunset capeknya hilang dalam seketika. #sunset', 'uploads/download.jpg', '2023-08-25 19:43:42');

-- --------------------------------------------------------

--
-- Struktur dari tabel `post_tags`
--

CREATE TABLE `post_tags` (
  `post_id` varchar(50) NOT NULL,
  `tag_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `post_tags`
--

INSERT INTO `post_tags` (`post_id`, `tag_id`) VALUES
('e651c6bf-5c52-4694-8ae8-9d1332', '7e7faf11-1c6e-4268-92c8-87ccaa'),
('a32ea095-37a8-4988-8b2b-2d69345cf7b8', 'f9c88fea-2ef2-4ebe-9019-fafa2fc121d8'),
('a32ea095-37a8-4988-8b2b-2d69345cf7b8', 'e5908a67-9d98-4add-ae09-b06ae135678d'),
('ec2498ce-11de-403d-bc16-bd8a64c15339', '6372245a-bb43-493b-b45a-40c38a848bf7'),
('d382486c-a8ee-414d-8983-44a72b67633f', '3093d07a-6e04-420f-947a-3cc22f8a9038'),
('d382486c-a8ee-414d-8983-44a72b67633f', '8e26e3d7-2e62-4fdf-a0fa-9e1b8f2f1767'),
('0fb86de2-faba-4fa2-a2cf-36618511faa1', 'f9c88fea-2ef2-4ebe-9019-fafa2fc121d8'),
('b7186388-7a70-4825-945a-863d8065c110', '6fb9fbe8-193d-432c-a182-2941a25e6531'),
('b7186388-7a70-4825-945a-863d8065c110', '2fdca4a4-8ea9-436e-b581-f21a72a9e4e0'),
('b7186388-7a70-4825-945a-863d8065c110', '6fb9fbe8-193d-432c-a182-2941a25e6531'),
('b7186388-7a70-4825-945a-863d8065c110', '2fdca4a4-8ea9-436e-b581-f21a72a9e4e0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tags`
--

CREATE TABLE `tags` (
  `tag_id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tags`
--

INSERT INTO `tags` (`tag_id`, `name`) VALUES
('2fdca4a4-8ea9-436e-b581-f21a72a9e4e0', '#senyum'),
('3093d07a-6e04-420f-947a-3cc22f8a9038', '#sawit'),
('6372245a-bb43-493b-b45a-40c38a848bf7', '#sunset'),
('6fb9fbe8-193d-432c-a182-2941a25e6531', '#kamu'),
('7e7faf11-1c6e-4268-92c8-87ccaa', '#merasabahagia'),
('8e26e3d7-2e62-4fdf-a0fa-9e1b8f2f1767', '#kampar'),
('e5908a67-9d98-4add-ae09-b06ae135678d', '#anakgunung'),
('f9c88fea-2ef2-4ebe-9019-fafa2fc121d8', '#gunung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `uuid` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`uuid`, `email`, `password`, `created`, `keterangan`, `name`, `picture`) VALUES
('e31sd143123dsasd', 'roni@gmail.com', '$2a$10$/ThJJeT39K3JiHRMJFS6W.pgPlZlLHNOU3AC7GPEFk7UwjXIGUkl.', '2023-08-22 17:30:49', 'Saya adalah mahasiswa Politeknik Kampar', 'RONI', 'uploads/yuhu.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`uuid`);

--
-- Indeks untuk tabel `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`like_id`);

--
-- Indeks untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`uuid`);

--
-- Indeks untuk tabel `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tag_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uuid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `likes`
--
ALTER TABLE `likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
