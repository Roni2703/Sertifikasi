<?php
$baseURL = 'http://localhost/sertifikasi/';

date_default_timezone_set('Asia/Jakarta');
